---
name: New Contributor
about: Add a new contributor.
title: New Contributor
labels: engineering, 500
assignees: ''

---

Team: [TEAM NAME]

{
  "title": [JOB TITLE],
  "isLead": [true OR false],
  "hourlyRate": [HOURLY RATE],
  "contributor": {
    "discordUsername": [DISCORD USERNAME],
    "displayName": [DISPLAY NAME],
    "githubUsername": [GITHUB USERNAME],
    "profileImage": [PROFILE IMAGE URL (GitHub URL)]
  }
}
