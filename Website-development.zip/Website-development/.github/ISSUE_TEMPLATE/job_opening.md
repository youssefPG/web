---
name: Job description
about: Post a job description
title: ''
labels: 1000, Job Description, engineering
assignees: ''

---

Add the following job opening to the website.

***

#### Job Title
Sample Job Title

#### Job Description
Write a few sentences describing the position here.

#### Responsibilities
- a
- b
- c

#### Requirements
- a
- b
- c

#### Reports To
- First Name: [FIRST NAME HERE]
- Discord Username: [DISCORD USERNAME HERE]
