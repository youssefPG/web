export const BANK_ENDPOINT = 'http://157.230.75.212/banks?limit=30&offset=0';
export const IPAPI_ENDPOINT = 'http://ip-api.com/batch/';
export const VALIDATOR_ENDPOINT = 'http://157.230.75.212/validators?limit=30&offset=0';
