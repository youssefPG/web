export const SIGNING_KEY_LENGTH_ERROR = 'Signing key must be 64 characters long';
export const SIGNING_KEY_REQUIRED_ERROR = 'Signing key is required';
