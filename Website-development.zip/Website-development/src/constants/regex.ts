export const REGEX = {excludingNumber: /[^\d.]/g};
