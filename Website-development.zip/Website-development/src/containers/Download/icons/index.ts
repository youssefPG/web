import LinuxIcon from './LinuxIcon';
import MacOsIcon from './MacOsIcon';
import WindowsIcon from './WindowsIcon';

export {LinuxIcon, MacOsIcon, WindowsIcon};
