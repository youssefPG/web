export interface CustomIconProps {
  size: number | string;
  state: 'default' | 'hover' | 'active';
}
