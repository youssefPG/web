export interface NavOption {
  pathname: string;
  title: string;
}
