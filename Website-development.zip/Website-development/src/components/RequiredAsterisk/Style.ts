import styled from 'styled-components';
import colors from 'styles/colors';

export const RequiredAsterisk = styled.span`
  color: ${colors.alert};
  margin-left: 3px;
`;
